// controllers/authController.js
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { addUser, findUserByEmail } from '../models/userModel.js';

const JWT_SECRET = 'your_jwt_secret'; // Use environment variable for production

export const register = async (req, res, next) => {
  const { name, email, password } = req.body;
  const existingUser = findUserByEmail(email);

  if (existingUser) {
    return next(new Error('User already exists'));
  }

  const hashedPassword = await bcrypt.hash(password, 12);
  const user = addUser(name, email, hashedPassword);

  res.status(201).json({ user });
};

export const login = async (req, res, next) => {
  const { email, password } = req.body;
  const user = findUserByEmail(email);

  if (!user) {
    return next(new Error('Invalid email or password'));
  }

  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    return next(new Error('Invalid email or password'));
  }

  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '1h' });
  res.status(200).json({ token });
};
