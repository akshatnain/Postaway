// controllers/postController.js
import { addPost, getAllPosts, getPostById, updatePost, deletePost, getUserPosts } from '../models/postModel.js';

export const createPost = (req, res, next) => {
  const { userId } = req.user;
  const { caption, imageUrl } = req.body;
  const post = addPost(userId, caption, imageUrl);
  res.status(201).json({ post });
};

export const getPosts = (req, res, next) => {
  const posts = getAllPosts();
  res.status(200).json({ posts });
};

export const getPost = (req, res, next) => {
  const { id } = req.params;
  const post = getPostById(id);
  if (!post) {
    return next(new Error('Post not found'));
  }
  res.status(200).json({ post });
};

export const updatePostById = (req, res, next) => {
  const { id } = req.params;
  const { caption, imageUrl } = req.body;
  const post = updatePost(id, caption, imageUrl);
  if (!post) {
    return next(new Error('Post not found'));
  }
  res.status(200).json({ post });
};

export const deletePostById = (req, res, next) => {
  const { id } = req.params;
  const post = deletePost(id);
  if (!post) {
    return next(new Error('Post not found'));
  }
  res.status(200).json({ post });
};
