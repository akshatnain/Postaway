// controllers/likeController.js
import { addLike, removeLike, getLikesByPostId } from '../models/likeModel.js';

export const toggleLike = (req, res, next) => {
  const { userId } = req.user;
  const { postId } = req.params;

  const existingLike = getLikesByPostId(postId).find(like => like.userId === userId);
  let like;
  if (existingLike) {
    like = removeLike(userId, postId);
  } else {
    like = addLike(userId, postId);
  }

  res.status(200).json({ like });
};

export const getLikes = (req, res, next) => {
  const { postId } = req.params;
  const likes = getLikesByPostId(postId);
  res.status(200).json({ likes });
};
