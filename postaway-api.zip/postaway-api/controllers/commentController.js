// controllers/commentController.js
import { addComment, getCommentsByPostId, updateComment, deleteComment } from '../models/commentModel.js';

export const createComment = (req, res, next) => {
  const { userId } = req.user;
  const { postId } = req.params;
  const { content } = req.body;
  const comment = addComment(userId, postId, content);
  res.status(201).json({ comment });
};

export const getComments = (req, res, next) => {
  const { postId } = req.params;
  const comments = getCommentsByPostId(postId);
  res.status(200).json({ comments });
};

export const updateCommentById = (req, res, next) => {
  const { id } = req.params;
  const { content } = req.body;
  const comment = updateComment(id, content);
  if (!comment) {
    return next(new Error('Comment not found'));
  }
  res.status(200).json({ comment });
};

export const deleteCommentById = (req, res, next) => {
  const { id } = req.params;
  const comment = deleteComment(id);
  if (!comment) {
    return next(new Error('Comment not found'));
  }
  res.status(200).json({ comment });
};
