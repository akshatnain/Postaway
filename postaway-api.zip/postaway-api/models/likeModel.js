// models/likeModel.js
import { v4 as uuidv4 } from 'uuid';

const likes = [];

export const addLike = (userId, postId) => {
  const like = { id: uuidv4(), userId, postId };
  likes.push(like);
  return like;
};

export const removeLike = (userId, postId) => {
  const index = likes.findIndex(like => like.userId === userId && like.postId === postId);
  if (index !== -1) {
    return likes.splice(index, 1)[0];
  }
};

export const getLikesByPostId = (postId) => likes.filter(like => like.postId === postId);
