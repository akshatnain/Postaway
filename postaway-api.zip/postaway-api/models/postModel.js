// models/postModel.js
import { v4 as uuidv4 } from 'uuid';

const posts = [];

export const addPost = (userId, caption, imageUrl) => {
  const post = { id: uuidv4(), userId, caption, imageUrl, likes: [], comments: [] };
  posts.push(post);
  return post;
};

export const getAllPosts = () => posts;

export const getPostById = (id) => posts.find(post => post.id === id);

export const getUserPosts = (userId) => posts.filter(post => post.userId === userId);

export const updatePost = (id, caption, imageUrl) => {
  const post = getPostById(id);
  if (post) {
    post.caption = caption;
    post.imageUrl = imageUrl;
  }
  return post;
};

export const deletePost = (id) => {
  const index = posts.findIndex(post => post.id === id);
  if (index !== -1) {
    return posts.splice(index, 1)[0];
  }
};
