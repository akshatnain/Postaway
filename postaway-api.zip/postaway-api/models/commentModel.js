// models/commentModel.js
import { v4 as uuidv4 } from 'uuid';

const comments = [];

export const addComment = (userId, postId, content) => {
  const comment = { id: uuidv4(), userId, postId, content };
  comments.push(comment);
  return comment;
};

export const getCommentsByPostId = (postId) => comments.filter(comment => comment.postId === postId);

export const updateComment = (id, content) => {
  const comment = comments.find(comment => comment.id === id);
  if (comment) {
    comment.content = content;
  }
  return comment;
};

export const deleteComment = (id) => {
  const index = comments.findIndex(comment => comment.id === id);
  if (index !== -1) {
    return comments.splice(index, 1)[0];
  }
};
