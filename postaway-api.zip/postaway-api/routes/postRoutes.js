// routes/postRoutes.js
import express from 'express';
import { createPost, getPosts, getPost, updatePostById, deletePostById } from '../controllers/postController.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/all', getPosts);
router.get('/:id', getPost);
router.post('/', authenticate, createPost);
router.put('/:id', authenticate, updatePostById);
router.delete('/:id', authenticate, deletePostById);

export default router;
