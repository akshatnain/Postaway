// routes/likeRoutes.js
import express from 'express';
import { toggleLike, getLikes } from '../controllers/likeController.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/post/:postId', getLikes);
router.get('/toggle/post/:postId', authenticate, toggleLike);

export default router;
