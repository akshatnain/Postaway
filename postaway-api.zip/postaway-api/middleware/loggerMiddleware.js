// middleware/loggerMiddleware.js
export const logger = (req, res, next) => {
    if (!req.url.startsWith('/api/user')) {
      console.log(`Request URL: ${req.url}`);
      console.log(`Request Body: ${JSON.stringify(req.body)}`);
    }
    next();
  };
  